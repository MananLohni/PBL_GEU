#include <iostream>
#include <string>
#include "crow/crow_all.h"
#include "nlohmann/json.hpp"
#include "models/Subject.hpp"
#include "models/Topic.hpp"
#include "services/SubjectManager.hpp"
#include "services/TopicManager.hpp"
#include "dsa/SearchSortEngine.hpp"

// Helper function to build standardized JSON responses with CORS headers
inline crow::response makeJsonResponse(int statusCode, const nlohmann::json& payload) {
    crow::response res(statusCode, payload.dump());
    res.set_header("Content-Type", "application/json");
    res.set_header("Access-Control-Allow-Origin", "*");
    res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
    res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
    return res;
}

int main() {
    std::cout << "===========================================" << std::endl;
    std::cout << "  STUDYWISE C++ Backend - Stage 3.5        " << std::endl;
    std::cout << "  Data Model: examDate on Subject           " << std::endl;
    std::cout << "===========================================" << std::endl;

    // Initialize Managers and load persistent JSON data
    SubjectManager subjectManager("backend/data/subjects.json");
    TopicManager topicManager("backend/data/topics.json");

    subjectManager.loadFromFile();
    topicManager.loadFromFile();

    std::cout << "[INIT] Active Subjects: " << subjectManager.count() << std::endl;
    std::cout << "[INIT] Active Topics:   " << topicManager.count() << std::endl;

    // Setup Crow app with CORS middleware
    crow::App<crow::CORSHandler> app;

    auto& cors = app.get_middleware<crow::CORSHandler>();
    cors.global()
        .origin("*")
        .methods(crow::HTTPMethod::Get, crow::HTTPMethod::Post,
                 crow::HTTPMethod::Put, crow::HTTPMethod::Delete,
                 crow::HTTPMethod::Patch, crow::HTTPMethod::Options)
        .headers("Content-Type", "Authorization", "X-Requested-With");

    // Root info endpoint
    CROW_ROUTE(app, "/")
    ([]() {
        nlohmann::json info = {
            {"project", "STUDYWISE"},
            {"stage", "3.5"},
            {"status", "online"},
            {"modules", {"Subject Management", "Topic Management", "DSA Linear Search", "DSA Binary Search", "DSA Merge Sort"}}
        };
        return makeJsonResponse(200, info);
    });

    // GET /api/health
    CROW_ROUTE(app, "/api/health")
    ([]() {
        nlohmann::json health = {
            {"status", "ok"},
            {"message", "StudyWise C++ backend is running"},
            {"dsaEngine", "Active (LinearSearch, BinarySearch, MergeSort)"}
        };
        return makeJsonResponse(200, health);
    });

    // ==========================================
    // SUBJECT MANAGEMENT ENDPOINTS
    // ==========================================

    // GET /api/subjects - List all subjects with topic counts
    CROW_ROUTE(app, "/api/subjects")
    .methods(crow::HTTPMethod::Get)
    ([&subjectManager, &topicManager]() {
        nlohmann::json result = nlohmann::json::array();
        for (const auto& sub : subjectManager.getAllSubjects()) {
            nlohmann::json item = sub.toJson();
            item["topicCount"] = topicManager.countTopicsForSubject(sub.getId());
            result.push_back(item);
        }
        return makeJsonResponse(200, result);
    });

    // POST /api/subjects - Create a new subject
    CROW_ROUTE(app, "/api/subjects")
    .methods(crow::HTTPMethod::Post)
    ([&subjectManager](const crow::request& req) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (const std::exception& e) {
            return makeJsonResponse(400, {{"error", "Malformed JSON request body."}});
        }

        std::string name     = body.value("name", "");
        std::string code     = body.value("code", "");
        std::string semester = body.value("semester", "");
        std::string examDate = body.value("examDate", "");

        std::string errorMsg;
        auto created = subjectManager.addSubject(name, code, semester, examDate, errorMsg);
        if (!created.has_value()) {
            return makeJsonResponse(400, {{"error", errorMsg}});
        }

        nlohmann::json resJson = {
            {"status", "ok"},
            {"message", "Subject created successfully."},
            {"subject", created->toJson()}
        };
        return makeJsonResponse(201, resJson);
    });

    // DELETE /api/subjects/:id - Delete subject (with topic safety check)
    CROW_ROUTE(app, "/api/subjects/<string>")
    .methods(crow::HTTPMethod::Delete)
    ([&subjectManager, &topicManager](const std::string& id) {
        std::string errorMsg;
        bool deleted = subjectManager.deleteSubject(
            id,
            [&topicManager](const std::string& subId) {
                return topicManager.hasTopicsForSubject(subId);
            },
            errorMsg
        );

        if (!deleted) {
            int code = (errorMsg == "Subject not found.") ? 404 : 400;
            return makeJsonResponse(code, {{"error", errorMsg}});
        }

        return makeJsonResponse(200, {
            {"status", "ok"},
            {"message", "Subject deleted successfully."}
        });
    });

    // PUT /api/subjects/:id - Update an existing subject
    CROW_ROUTE(app, "/api/subjects/<string>")
    .methods(crow::HTTPMethod::Put)
    ([&subjectManager](const crow::request& req, const std::string& id) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (const std::exception& e) {
            return makeJsonResponse(400, {{"error", "Malformed JSON request body."}});
        }

        std::string errorMsg;
        auto updated = subjectManager.updateSubject(id, body, errorMsg);
        if (!updated.has_value()) {
            int code = (errorMsg == "Subject not found.") ? 404 : 400;
            return makeJsonResponse(code, {{"error", errorMsg}});
        }

        nlohmann::json resJson = {
            {"status", "ok"},
            {"message", "Subject updated successfully."},
            {"subject", updated->toJson()}
        };
        return makeJsonResponse(200, resJson);
    });

    // ==========================================
    // TOPIC MANAGEMENT ENDPOINTS
    // ==========================================

    // GET /api/topics - List all topics (supports ?subjectId=<id>)
    CROW_ROUTE(app, "/api/topics")
    .methods(crow::HTTPMethod::Get)
    ([&topicManager](const crow::request& req) {
        const char* subIdParam = req.url_params.get("subjectId");
        std::string filter = (subIdParam != nullptr) ? subIdParam : "";

        std::vector<Topic> topics = topicManager.getAllTopics(filter);
        nlohmann::json result = nlohmann::json::array();
        for (const auto& t : topics) {
            result.push_back(t.toJson());
        }
        return makeJsonResponse(200, result);
    });

    // POST /api/topics - Create a new topic
    CROW_ROUTE(app, "/api/topics")
    .methods(crow::HTTPMethod::Post)
    ([&topicManager, &subjectManager](const crow::request& req) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (const std::exception& e) {
            return makeJsonResponse(400, {{"error", "Malformed JSON request body."}});
        }

        std::string errorMsg;
        auto created = topicManager.addTopic(body, subjectManager, errorMsg);
        if (!created.has_value()) {
            return makeJsonResponse(400, {{"error", errorMsg}});
        }

        nlohmann::json resJson = {
            {"status", "ok"},
            {"message", "Topic created successfully."},
            {"topic", created->toJson()}
        };
        return makeJsonResponse(201, resJson);
    });

    // PUT /api/topics/:id - Edit/Update an existing topic
    CROW_ROUTE(app, "/api/topics/<string>")
    .methods(crow::HTTPMethod::Put)
    ([&topicManager, &subjectManager](const crow::request& req, const std::string& id) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (const std::exception& e) {
            return makeJsonResponse(400, {{"error", "Malformed JSON request body."}});
        }

        std::string errorMsg;
        auto updated = topicManager.updateTopic(id, body, subjectManager, errorMsg);
        if (!updated.has_value()) {
            int code = (errorMsg == "Topic not found.") ? 404 : 400;
            return makeJsonResponse(code, {{"error", errorMsg}});
        }

        nlohmann::json resJson = {
            {"status", "ok"},
            {"message", "Topic updated successfully."},
            {"topic", updated->toJson()}
        };
        return makeJsonResponse(200, resJson);
    });

    // DELETE /api/topics/:id - Delete a topic
    CROW_ROUTE(app, "/api/topics/<string>")
    .methods(crow::HTTPMethod::Delete)
    ([&topicManager](const std::string& id) {
        std::string errorMsg;
        bool deleted = topicManager.deleteTopic(id, errorMsg);
        if (!deleted) {
            return makeJsonResponse(404, {{"error", errorMsg}});
        }

        return makeJsonResponse(200, {
            {"status", "ok"},
            {"message", "Topic deleted successfully."}
        });
    });

    // PATCH /api/topics/:id/status - Update topic status (NOT_STARTED, IN_PROGRESS, COMPLETED)
    CROW_ROUTE(app, "/api/topics/<string>/status")
    .methods(crow::HTTPMethod::Patch)
    ([&topicManager](const crow::request& req, const std::string& id) {
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (const std::exception& e) {
            return makeJsonResponse(400, {{"error", "Malformed JSON request body."}});
        }

        if (!body.contains("status") || body["status"].is_null() || !body["status"].is_string()) {
            return makeJsonResponse(400, {{"error", "Status field is required (e.g. 'NOT_STARTED', 'IN_PROGRESS', 'COMPLETED')."}});
        }

        std::string newStatus = body["status"].get<std::string>();
        std::string errorMsg;
        auto updated = topicManager.updateTopicStatus(id, newStatus, errorMsg);
        if (!updated.has_value()) {
            int code = (errorMsg == "Topic not found.") ? 404 : 400;
            return makeJsonResponse(code, {{"error", errorMsg}});
        }

        nlohmann::json resJson = {
            {"status", "ok"},
            {"message", "Topic status updated successfully."},
            {"topic", updated->toJson()}
        };
        return makeJsonResponse(200, resJson);
    });

    // ==========================================
    // STAGE 3: DSA SEARCH ENDPOINTS
    // ==========================================

    // GET /api/search?q=<query>&entity=topics|subjects
    // Executes C++ Linear Search - O(n)
    CROW_ROUTE(app, "/api/search")
    .methods(crow::HTTPMethod::Get)
    ([&topicManager, &subjectManager](const crow::request& req) {
        const char* qParam = req.url_params.get("q");
        const char* entityParam = req.url_params.get("entity");

        std::string query = (qParam != nullptr) ? qParam : "";
        std::string entity = (entityParam != nullptr) ? entityParam : "topics";

        if (entity == "subjects") {
            std::vector<Subject> matches = SearchSortEngine::linearSearchSubjects(
                subjectManager.getAllSubjects(),
                query
            );

            nlohmann::json resultsJson = nlohmann::json::array();
            for (const auto& s : matches) {
                nlohmann::json item = s.toJson();
                item["topicCount"] = topicManager.countTopicsForSubject(s.getId());
                resultsJson.push_back(item);
            }

            nlohmann::json response = {
                {"results", resultsJson},
                {"count", matches.size()},
                {"algorithm", "Linear Search"},
                {"timeComplexity", "O(n)"},
                {"entity", "subjects"},
                {"query", query}
            };
            return makeJsonResponse(200, response);
        } else {
            // Default entity: topics
            std::vector<Topic> matches = SearchSortEngine::linearSearchTopics(
                topicManager.getAllTopics(),
                query,
                [&subjectManager](const std::string& subId) -> std::string {
                    auto sub = subjectManager.getSubjectById(subId);
                    return sub.has_value() ? sub->getName() : "";
                }
            );

            nlohmann::json resultsJson = nlohmann::json::array();
            for (const auto& t : matches) {
                resultsJson.push_back(t.toJson());
            }

            nlohmann::json response = {
                {"results", resultsJson},
                {"count", matches.size()},
                {"algorithm", "Linear Search"},
                {"timeComplexity", "O(n)"},
                {"entity", "topics"},
                {"query", query}
            };
            return makeJsonResponse(200, response);
        }
    });

    // GET /api/search/topic-exact?q=<topicName>
    // Executes C++ Binary Search - O(log n)
    CROW_ROUTE(app, "/api/search/topic-exact")
    .methods(crow::HTTPMethod::Get)
    ([&topicManager](const crow::request& req) {
        const char* qParam = req.url_params.get("q");
        std::string target = (qParam != nullptr) ? qParam : "";

        if (target.empty()) {
            return makeJsonResponse(400, {
                {"error", "Query parameter 'q' is required for exact topic lookup."},
                {"algorithm", "Binary Search"}
            });
        }

        auto match = SearchSortEngine::binarySearchTopicExact(
            topicManager.getAllTopics(),
            target
        );

        if (match.has_value()) {
            nlohmann::json response = {
                {"found", true},
                {"result", match->toJson()},
                {"algorithm", "Binary Search"},
                {"timeComplexity", "O(log n)"},
                {"target", target}
            };
            return makeJsonResponse(200, response);
        } else {
            nlohmann::json response = {
                {"found", false},
                {"result", nullptr},
                {"algorithm", "Binary Search"},
                {"timeComplexity", "O(log n)"},
                {"message", "No exact topic match was found."},
                {"target", target}
            };
            return makeJsonResponse(200, response);
        }
    });

    // ==========================================
    // STAGE 3: DSA SORT ENDPOINTS
    // ==========================================

    // GET /api/sort?entity=topics|subjects&by=<field>&order=asc|desc
    // Executes C++ Merge Sort - O(n log n)
    CROW_ROUTE(app, "/api/sort")
    .methods(crow::HTTPMethod::Get)
    ([&topicManager, &subjectManager](const crow::request& req) {
        const char* entityParam = req.url_params.get("entity");
        const char* byParam = req.url_params.get("by");
        const char* orderParam = req.url_params.get("order");

        std::string entity = (entityParam != nullptr) ? entityParam : "topics";
        std::string by = (byParam != nullptr) ? byParam : "name";
        std::string order = (orderParam != nullptr) ? orderParam : "asc";
        bool ascending = (order != "desc");

        if (entity == "subjects") {
            std::vector<Subject> sorted = SearchSortEngine::sortSubjects(
                subjectManager.getAllSubjects(),
                by,
                ascending
            );

            nlohmann::json resultsJson = nlohmann::json::array();
            for (const auto& s : sorted) {
                nlohmann::json item = s.toJson();
                item["topicCount"] = topicManager.countTopicsForSubject(s.getId());
                resultsJson.push_back(item);
            }

            nlohmann::json response = {
                {"results", resultsJson},
                {"count", sorted.size()},
                {"algorithm", "Merge Sort"},
                {"criteria", by},
                {"order", ascending ? "asc" : "desc"},
                {"timeComplexity", "O(n log n)"},
                {"entity", "subjects"}
            };
            return makeJsonResponse(200, response);
        } else {
            // Default entity: topics
            std::vector<Topic> sorted = SearchSortEngine::sortTopics(
                topicManager.getAllTopics(),
                by,
                ascending
            );

            nlohmann::json resultsJson = nlohmann::json::array();
            for (const auto& t : sorted) {
                resultsJson.push_back(t.toJson());
            }

            nlohmann::json response = {
                {"results", resultsJson},
                {"count", sorted.size()},
                {"algorithm", "Merge Sort"},
                {"criteria", by},
                {"order", ascending ? "asc" : "desc"},
                {"timeComplexity", "O(n log n)"},
                {"entity", "topics"}
            };
            return makeJsonResponse(200, response);
        }
    });

    std::cout << "[INFO] StudyWise C++ backend listening on http://127.0.0.1:8080" << std::endl;
    std::cout << "[INFO] Ready endpoints:" << std::endl;
    std::cout << "       - GET    /api/health" << std::endl;
    std::cout << "       - GET    /api/subjects" << std::endl;
    std::cout << "       - POST   /api/subjects" << std::endl;
    std::cout << "       - PUT    /api/subjects/<id>" << std::endl;
    std::cout << "       - DELETE /api/subjects/<id>" << std::endl;
    std::cout << "       - GET    /api/topics (?subjectId=<id>)" << std::endl;
    std::cout << "       - POST   /api/topics" << std::endl;
    std::cout << "       - PUT    /api/topics/<id>" << std::endl;
    std::cout << "       - DELETE /api/topics/<id>" << std::endl;
    std::cout << "       - PATCH  /api/topics/<id>/status" << std::endl;
    std::cout << "       - GET    /api/search (?q=<query>&entity=topics|subjects)" << std::endl;
    std::cout << "       - GET    /api/search/topic-exact (?q=<topicName>)" << std::endl;
    std::cout << "       - GET    /api/sort (?entity=topics|subjects&by=<field>&order=asc|desc)" << std::endl;

    app.port(8080)
       .multithreaded()
       .run();

    return 0;
}
