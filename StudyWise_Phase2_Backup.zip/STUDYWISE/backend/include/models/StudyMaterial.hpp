#ifndef STUDY_MATERIAL_HPP
#define STUDY_MATERIAL_HPP

#include <string>
#include "nlohmann/json.hpp"

class StudyMaterial {
private:
    std::string id;
    std::string title;
    std::string subjectId;
    std::string topicId;
    std::string fileType;       // "PDF", "NOTES", "SLIDES", "OTHER"
    std::string filePath;       // relative or absolute path
    std::string uploadDate;     // ISO timestamp or date
    long long fileSize{0};      // in bytes

public:
    StudyMaterial() = default;

    StudyMaterial(std::string id, std::string title, std::string subjectId,
                  std::string topicId, std::string fileType, std::string filePath,
                  std::string uploadDate = "", long long fileSize = 0)
        : id(std::move(id)), title(std::move(title)), subjectId(std::move(subjectId)),
          topicId(std::move(topicId)), fileType(std::move(fileType)),
          filePath(std::move(filePath)), uploadDate(std::move(uploadDate)), fileSize(fileSize) {}

    // Getters
    const std::string& getId() const { return id; }
    const std::string& getTitle() const { return title; }
    const std::string& getSubjectId() const { return subjectId; }
    const std::string& getTopicId() const { return topicId; }
    const std::string& getFileType() const { return fileType; }
    const std::string& getFilePath() const { return filePath; }
    const std::string& getUploadDate() const { return uploadDate; }
    long long getFileSize() const { return fileSize; }

    // Setters
    void setId(const std::string& newId) { id = newId; }
    void setTitle(const std::string& newTitle) { title = newTitle; }
    void setSubjectId(const std::string& newSubId) { subjectId = newSubId; }
    void setTopicId(const std::string& newTopId) { topicId = newTopId; }
    void setFileType(const std::string& newType) { fileType = newType; }
    void setFilePath(const std::string& newPath) { filePath = newPath; }
    void setUploadDate(const std::string& newDate) { uploadDate = newDate; }
    void setFileSize(long long newSize) { fileSize = newSize; }

    // Serialization
    nlohmann::json toJson() const {
        return nlohmann::json{
            {"id", id},
            {"title", title},
            {"subjectId", subjectId},
            {"topicId", topicId},
            {"fileType", fileType},
            {"filePath", filePath},
            {"uploadDate", uploadDate},
            {"fileSize", fileSize}
        };
    }

    static StudyMaterial fromJson(const nlohmann::json& j) {
        StudyMaterial m;
        if (j.contains("id") && !j["id"].is_null()) m.id = j["id"].get<std::string>();
        if (j.contains("title") && !j["title"].is_null()) m.title = j["title"].get<std::string>();
        if (j.contains("subjectId") && !j["subjectId"].is_null()) m.subjectId = j["subjectId"].get<std::string>();
        if (j.contains("topicId") && !j["topicId"].is_null()) m.topicId = j["topicId"].get<std::string>();
        if (j.contains("fileType") && !j["fileType"].is_null()) m.fileType = j["fileType"].get<std::string>();
        if (j.contains("filePath") && !j["filePath"].is_null()) m.filePath = j["filePath"].get<std::string>();
        if (j.contains("uploadDate") && !j["uploadDate"].is_null()) m.uploadDate = j["uploadDate"].get<std::string>();
        if (j.contains("fileSize") && !j["fileSize"].is_null()) m.fileSize = j["fileSize"].get<long long>();
        return m;
    }
};

#endif // STUDY_MATERIAL_HPP
